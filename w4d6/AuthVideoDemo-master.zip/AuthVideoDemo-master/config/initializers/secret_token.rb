# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
AuthDemo::Application.config.secret_key_base = '00ac818e04f80f9ac5ec5032d2eec8fe2006a34d4fba85dcdef5ebe5d656b10851c092e915ddd5779e9a201f18a717c7a50e8eea130943ca49ff3fad887ad6ad'
